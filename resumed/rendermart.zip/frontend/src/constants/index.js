
//generate a list of Cards
const cardsMarketPlace = [
    {
        imageUrl:"https://placehold.co/600x400",
        price:"599"
    },
    {
        imageUrl:"https://placehold.co/600x400",
        price:"599"
    },
    {
        imageUrl:"https://placehold.co/600x400",
        price:"599"
    },
    {
        imageUrl:"https://placehold.co/600x400",
        price:"599"
    },
    {
        imageUrl:"https://placehold.co/600x400",
        price:"599"
    },
    {
        imageUrl:"https://placehold.co/600x400",
        price:"599"
    },
]

const cardsWallet = [
    {
        imageUrl:"https://placehold.co/600x400",
        state:true
    },
    {
        imageUrl:"https://placehold.co/600x400",
        state:false
    },
    {
        imageUrl:"https://placehold.co/600x400",
        state:true
    }
]

const soldCards = [
    {
      imageUrl: "https://placehold.co/400x300",
      price: "599",
      buyer: "John Doe",
      dateSold: "2025-01-01",
    },
    {
      imageUrl: "https://placehold.co/400x300",
      price: "799",
      buyer: "Jane Smith",
      dateSold: "2025-01-15",
    },
    {
      imageUrl: "https://placehold.co/400x300",
      price: "999",
      buyer: "Alice Johnson",
      dateSold: "2025-01-20",
    },
  ];

export {cardsMarketPlace, cardsWallet, soldCards}