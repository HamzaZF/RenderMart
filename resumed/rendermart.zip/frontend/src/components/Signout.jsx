import React from 'react'

function Signout() {
  return (
    <div>Signout</div>
  )
}

export default Signout